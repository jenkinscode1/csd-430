CREATE DATABASE IF NOT EXISTS CSD430;
USE CSD430;

CREATE TABLE jelani_movies_data (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    genre VARCHAR(50),
    release_year INT,
    rating DECIMAL(3,1),
    director VARCHAR(100)
);

INSERT INTO jelani_movies_data (title, genre, release_year, rating, director) VALUES
('Inception', 'Science Fiction', 2010, 8.8, 'Christopher Nolan'),
('The Matrix', 'Action', 1999, 8.7, 'The Wachowskis'),
('Gladiator', 'Drama', 2000, 8.5, 'Ridley Scott'),
('Interstellar', 'Adventure', 2014, 8.6, 'Christopher Nolan'),
('The Dark Knight', 'Action', 2008, 9.0, 'Christopher Nolan'),
('Titanic', 'Romance', 1997, 7.8, 'James Cameron'),
('Avatar', 'Science Fiction', 2009, 7.9, 'James Cameron'),
('The Godfather', 'Crime', 1972, 9.2, 'Francis Ford Coppola'),
('Jurassic Park', 'Adventure', 1993, 8.1, 'Steven Spielberg'),
('Forrest Gump', 'Drama', 1994, 8.8, 'Robert Zemeckis');