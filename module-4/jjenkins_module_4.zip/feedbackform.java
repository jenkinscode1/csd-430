package feedback;
import java.io.Serializable;

public class feedbackform  implements Serializable {
    private String name;
    private String email;
    private String meal;
    private int rating;
    private String comments;

    public feedbackform() {}

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getMeal() { return meal; }
    public void setMeal(String meal) { this.meal = meal; }

    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }

    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
}

